// import axios from 'axios';

// const loginBaseURL = `http://localhost:8080/api/employee/login`

// const LoginService = async (credentials) => {
//     const response = await axios.post(loginBaseURL, credentials)
//     // console.log(response.data);
//     return response;
// }

// const exportObj = { LoginService }
// export default exportObj