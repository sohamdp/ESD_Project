// import axios from 'axios'

// const employeesURL = `http://localhost/api/employees`

// const getEmployeeDetais = async () => {
//     const response = await axios.get(employeesURL)
//     return response.data
// }

// const exportObj = { getEmployeeDetais }

// export default exportObj