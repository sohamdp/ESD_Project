import React from 'react'

function Heading() {
    return (
        <div>
            <div className='text-center page-header mt-3 regular-text-shadow regular-shadow'>
                <div className='display-4 font-weight-bold'>
                    Acadamia-ERP 
                </div>
            </div>
        </div>
            )
}
export default Heading;