import React, { useState } from 'react'
import axios from 'axios'

const EmployeeDetails = ({ employee_id, fname, lname, email, title, salary, status }) => {


    const [modifiedsalary, setSalary] = useState('')


    const loginBaseURL = `http://localhost:8080/api/employee/Modify_salary_details`
    const modify = (event) => {
        event.preventDefault();
        modifySalary();
    }
    const parameters={
        employee_id, salary: parseFloat(modifiedsalary)
    }
    const modifySalary = async() => {
        console.log(parameters)
        await axios.post(loginBaseURL, parameters)
        .then(function (response) {
            console.log(response.data);
            window.localStorage.setItem('usersalary',JSON.stringify(response.data))
            window.location.reload(true)
            // var reply = JSON.parse(window.localStorage.getItem('loginuser'))
            // console.log("from local storage", reply)
        })
        .catch(function (error) {
            console.log(error);
        });
    }

    return (
        <tr>
            <td>
                <div className="form-check">
                    <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault"
                        onChange={() => { }}
                    />
                </div>
            </td>
            <td>{employee_id}</td>
            <td>{fname} {lname}</td>
            <td>{email}</td>
            <td>{title}</td>
            <td>{salary}</td>
            <td>    
                <input className="form-control " id="ex1" placeholder="Salary" type="text" style={{width:"100px",paddingLeft:"10px"}} onChange={event => setSalary(event.target.value)}/>
            </td>
            <td>
                <button type="button" className="btn btn-secondary" onClick={modify}>modify</button>
            </td>
        </tr>

    )
}
export default EmployeeDetails